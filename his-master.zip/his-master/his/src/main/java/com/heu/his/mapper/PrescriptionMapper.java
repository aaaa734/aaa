package com.heu.his.mapper;

import org.apache.ibatis.annotations.Mapper;

/**
 * @author legend
 * @create 2022-07-31-11:27
 */
@Mapper
public interface PrescriptionMapper {

}
