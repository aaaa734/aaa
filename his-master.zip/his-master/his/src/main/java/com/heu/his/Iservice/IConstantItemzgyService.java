package com.heu.his.Iservice;

import com.heu.his.pojo.Constantitem;

import java.util.List;

/**
 * @author zhougy
 * @create 2022-07-29 9:35
 */
public interface IConstantItemzgyService {

    List<Constantitem> getDepartmentCategoryList();

    List<Constantitem> getDocTitleList();

}
