package com.heu.his.Iservice;

/**
 * @author legend
 * @create 2022-07-31-11:31
 */
public interface IPrescriptionService {
}
