package com.heu.his.Iservice;
/**
 * author:Hulake
 * time:2022/8/5
 */

import com.heu.his.pojo.Sex;

public interface ISexchService {
    java.util.List<Sex> getsexnamelist();
}
