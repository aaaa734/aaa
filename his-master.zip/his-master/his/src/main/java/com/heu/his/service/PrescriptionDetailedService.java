package com.heu.his.service;

import com.heu.his.Iservice.IPrescriptionDetailedService;
import org.springframework.stereotype.Service;

/**
 * @author legend
 * @create 2022-07-31-11:29
 */
@Service
public class PrescriptionDetailedService implements IPrescriptionDetailedService {
}
