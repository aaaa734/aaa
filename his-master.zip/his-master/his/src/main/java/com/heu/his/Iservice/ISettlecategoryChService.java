package com.heu.his.Iservice;

import com.heu.his.pojo.Settlecategory;

public interface ISettlecategoryChService {
    java.util.List<Settlecategory> getsettlecategoryname();
}
