package com.heu.his.Iservice;

import com.heu.his.pojo.Patientcosts;

/**
 * author:Hulake
 * time:2022/8/3
 */

public interface IPatientcostschService {

    java.util.List<Patientcosts> getPatientcostsList(int RID);
}
