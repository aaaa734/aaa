package com.heu.his.Iservice;
/**
 * author:Hulake
 * time:2022/8/3
 */

import com.heu.his.pojo.Department;

public interface IDepartmentchService {

    java.util.List<Department> getdepartment();
}
